-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 27, 2019 at 12:37 PM
-- Server version: 5.7.27-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-10+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `mobile` bigint(30) DEFAULT NULL,
  `checkin` varchar(30) DEFAULT NULL,
  `checkout` varchar(30) DEFAULT NULL,
  `roomno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `name`, `email`, `mobile`, `checkin`, `checkout`, `roomno`) VALUES
(1, 'newCustomer', 'new@gmail.com', 9876543, '24/09/2019', '25/09/2019', 1),
(2, 'newCustomer', 'new@gmail.com', 988777, '26/09/2109', '27/09/2019', 1),
(3, 'new', 'new@gmail.com', 1234, '24/09/2019', '25/09/2019', 1),
(4, 'new ', 'new@gmail.com', 12421, '28/09/2019', '25/09/2019', 1),
(5, 'new ', 'new@gmail.com', 13242, '25/09/2019', '26/09/2019', 1),
(6, 'new ', 'new@gmail.com', 132412, '24/09/2019', '25/09/2019', 1),
(7, 'new ', 'new@gmail.com', 1323, '3294', '3293', 1),
(8, 'new', 'new@gmail.com', 13124, '24/09/2019', '25/09/2019', 1),
(9, 'himanshu', 'him@gmail.com', 885577, '2019-08-26', '2019-08-28', 1),
(10, 'newC', 'new@gmail.com', 89575, '2019-08-26', '2019-08-27', 2),
(11, 'newC', 'new@gmail.com', 89575, '2019-08-26', '2019-08-27', 102),
(12, 'gaurav', 'gaurav@gmail.com', 986361223, '2019-08-26', '2019-08-27', 103),
(13, 'newone', 'newone@gmail.com', 91247963, '2019-08-26', '2019-08-27', 104),
(14, 'newone', 'newone@gmail.com', 2948124, '2019-08-26', '2019-08-27', 104),
(15, 'g', 'gjhg@gmail.com', 536435435, '01/02/1009', '10/02/2001', 109),
(16, 'himanshu', 'surjeet@gmail.com', 5546546, '2019-08-03', '2019-08-04', 110),
(17, 'himanshu', 'surjeet@gmail.com', 885577, '2019-08-26', '2019-08-27', 101),
(18, 'sfd', 's@gmail.com', 13254, '2019-08-27', '2019-08-28', 102),
(19, 'himanshu', 'surjeet@gmail.com', 9548451, '2019-08-27', '2019-08-29', 103),
(20, 'wfsdf', 'sf@gmail.com', 4556454, '01/02/2012', '02/02/2012', 104),
(21, 'dfdf', 'dfdfd@gmail.com', 45563435, '01/01/', '010', 105),
(22, 'himanshu', 'surjeet@gmail.com', 885577, '2019-08-27', '2019-08-29', 106),
(23, 'himanshu', 'a@gmail.com', 565416545, '2019-08-27', '2019-08-28', 107),
(24, 'himanshu', 'raghavravindra30895@gmail.com', 885577, '2019-08-27', '2019-08-28', 108),
(25, 'himanshu', 'raghavravindra30895@gmail.com', 885577, '2019-08-27', '2019-08-28', 108),
(26, 'himanshu', 'raghavravindra30895@gmail.com', 885577, '2019-08-27', '2019-08-28', 108),
(27, 'Surjeet', 'surjeetsrrr@gmail.com', 885577, '2019-08-27', '2019-08-28', 108),
(28, 'himanshu', 'surjeet@gmail.com', 561651651, '2019-08-27', '2019-08-27', 102),
(29, 'Milind', 'surjeet@gmail.com', 561651651, '2019-08-27', '2019-08-27', 102),
(30, 'himanshu', 'ergauravaroraa@gmail.com', 54656565, '', '', 101);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `mobile_number` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`name`, `email`, `password`, `mobile_number`) VALUES
('surjeet', 'surjeet@gmail.com', '1234', 785623857),
('himanshu', 'himanshu@gmail.com', '123456', 1234567890),
('ravindra', 'ravin@gmail.com', '123456', 9874562),
('gsfgs', 'sdgs', '4645', 4534537),
('Akshay', 'akshay@gmail.com', '123456', 1234567890),
('kunal', 'kunal@gmail.com', '123', 278983922);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_no` int(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_no`, `status`) VALUES
(101, 'false'),
(102, 'false'),
(103, 'false'),
(104, 'false'),
(105, 'false'),
(106, 'false'),
(107, 'false'),
(108, 'false'),
(109, 'false'),
(110, 'false');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
